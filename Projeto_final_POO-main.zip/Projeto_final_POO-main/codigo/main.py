
from janela import Janela

if __name__ == "__main__":
    janela = Janela()   
    janela.instanciar_janela()